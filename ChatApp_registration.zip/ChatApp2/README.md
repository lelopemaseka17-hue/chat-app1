# Chat App — POE Part 1: Registration and Login

PROG5121 Programming 1A — Portfolio of Evidence, Part 1 (100 marks).
Console-only Java application (no GUI), built on your `registration` class.

## Project structure

```
ChatApp/
├── pom.xml
├── README.md
└── src
    ├── main/java/lelopemaseka/
    │   ├── registration.java  (registration + login logic)
    │   ├── Message.java       (message payload + sent/received/read flags)
    │   └── Main.java          (console menu — all Scanner input lives here)
    └── test/java/lelopemaseka/
        ├── RegistrationTest.java  (JUnit 5 tests matching the brief's test data)
        └── MessageTest.java
```

## Changes made to your registration.java

1. **Validation methods no longer read from `Scanner` internally.** They previously
   ignored their parameter and prompted for console input instead, which meant
   `checkuserName("kyl_1")` couldn't be tested directly — it would try to read from
   the keyboard instead of validating `"kyl_1"`. They now validate the string you
   pass in, exactly as the brief's method signatures require.
2. All console prompting was moved into `Main.java`, which reads input once per
   field and passes it into `registerUser(...)` / `loginUser(...)`.
3. `checkCellPhoneNumber` had a type error (`int` compared to `null`) and no
   `return` — it's now a `String`-based check for `+27` followed by 9–10 digits.
4. Added a couple of extra getters (`getFirstName`, `getLastName`) — harmless,
   remove them if you don't need them.

Everything else — your package name, class name, field names, and message
text — is unchanged.

**Note:** the brief specifies the method name `checkUserName` (capital U); your
class uses `checkuserName`. I kept your spelling since renaming it would change
your existing code, but check your rubric — some markers check exact method
signatures.

## Requirements

- JDK 17 or later
- Maven 3.8+

## Running the app

```
mvn compile exec:java -Dexec.mainClass="lelopemaseka.Main"
```

## Running the unit tests

```
mvn test
```

Take a screenshot of the console output (or your IDE's test runner) showing all
tests passing — the brief requires this as evidence.

## Test data (from the POE brief)

| Test | Input | Expected |
|---|---|---|
| Username Pass | `kyl_1` | True |
| Username Fail | `kyle!!!!!!!` | False |
| Password Pass | `Ch&&sec@ke99!` | True |
| Password Fail | `password` | False |
| Cell Pass | `+27838968976` | True |
| Cell Fail | `08966553` | False |
| Login Success | (matching credentials) | True |
| Login Failed | (non-matching credentials) | False |

## Before you submit — checklist against the brief

- [ ] Push this project to a GitHub repository (a 5% penalty applies if not submitted via GitHub — see instruction 2 of the brief).
- [ ] Include screenshots of the JUnit tests passing (instruction 3).
- [ ] Complete the IEEE reference list below with the actual sources you used (instruction 4).
- [ ] Confirm the app has no GUI — this project is console-only (instruction 5).
- [ ] Record and submit a video walking through the running application and the passing tests (instruction 6).

## IEEE reference list (example — replace/expand with what you actually cited)

[1] Oracle, "The Java™ Tutorials," Oracle Corporation. [Online]. Available: https://docs.oracle.com/javase/tutorial/. [Accessed: 17-Sep-2026].

[2] JUnit Team, "JUnit 5 User Guide," 2024. [Online]. Available: https://junit.org/junit5/docs/current/user-guide/. [Accessed: 17-Sep-2026].

> Update this list with the specific pages/textbooks/lecture notes you actually
> referred to, and check your module guide's referencing rubric for exact
> formatting expectations.
