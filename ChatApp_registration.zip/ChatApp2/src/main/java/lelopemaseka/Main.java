package lelopemaseka;

import java.util.Scanner;

/**
 * Console entry point for the Chat App registration and login feature.
 * No GUI is used, as required by the POE brief. All console input is
 * handled here so that {@link registration}'s validation methods stay
 * pure and unit-testable.
 *
 * @author Student
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        registration reg = new registration();
        boolean running = true;

        while (running) {
            System.out.println("\n=== Chat App ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    System.out.print("Enter username (must contain '_', max 5 chars): ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password (8+ chars, capital, number, special char): ");
                    String password = scanner.nextLine();
                    System.out.print("Enter cell phone number (e.g. +27831234567): ");
                    String cell = scanner.nextLine();
                    System.out.println(reg.registerUser(username, password, cell));
                    break;

                case "2":
                    System.out.print("Enter username: ");
                    String loginUsername = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String loginPassword = scanner.nextLine();
                    boolean status = reg.loginUser(loginUsername, loginPassword);
                    System.out.print("Enter first name: ");
                    String firstName = scanner.nextLine();
                    System.out.print("Enter last name: ");
                    String lastName = scanner.nextLine();
                    System.out.println(reg.returnLoginStatus(status, firstName, lastName));
                    break;

                case "3":
                    running = false;
                    System.out.println("Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option, please try again.");
            }
        }

        scanner.close();
    }
}
