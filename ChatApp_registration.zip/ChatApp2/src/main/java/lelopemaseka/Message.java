package lelopemaseka;

import java.util.UUID;

/**
 * Represents a single chat message, tracking its text payload and its
 * delivery status flags (sent, received, read) in the style of WhatsApp
 * "ticks".
 *
 * @author Student
 */
public class Message {

    private final String messageId;
    private final String payload;
    private boolean sent;
    private boolean received;
    private boolean read;

    /**
     * Creates a new, unsent message with the given text payload.
     *
     * @param payload the text content of the message
     */
    public Message(String payload) {
        this.messageId = UUID.randomUUID().toString().substring(0, 8);
        this.payload = payload;
        this.sent = false;
        this.received = false;
        this.read = false;
    }

    /** Marks the message as sent (single grey tick). */
    public void markSent() {
        this.sent = true;
    }

    /** Marks the message as received by the recipient (double grey tick). */
    public void markReceived() {
        this.received = true;
    }

    /** Marks the message as read by the recipient (double blue tick). */
    public void markRead() {
        this.read = true;
        this.received = true;
        this.sent = true;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getPayload() {
        return payload;
    }

    public boolean isSent() {
        return sent;
    }

    public boolean isReceived() {
        return received;
    }

    public boolean isRead() {
        return read;
    }

    /**
     * Returns a text representation of the WhatsApp-style tick status
     * that reflects the current sent/received/read state.
     *
     * @return a string describing the tick status
     */
    public String getTickStatus() {
        if (read) {
            return "\u2714\u2714 (blue - read)";
        } else if (received) {
            return "\u2714\u2714 (grey - delivered)";
        } else if (sent) {
            return "\u2714 (grey - sent)";
        }
        return "(not sent)";
    }

    @Override
    public String toString() {
        return "[" + messageId + "] " + payload + "  " + getTickStatus();
    }
}
