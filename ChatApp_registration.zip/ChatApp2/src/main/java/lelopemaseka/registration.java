package lelopemaseka;

/**
 * Handles user registration and login functionality.
 * <p>
 * Validation logic is kept free of console input/output so that it can
 * be exercised directly by unit tests and reused by the console menu
 * in {@link Main}.
 *
 * @author Student
 */
public class registration {

    // Details of the currently registered user.
    private String registeredUsername;
    private String registeredPassword;
    private String registeredCellphone;
    private String firstName;
    private String lastName;

    /**
     * Default constructor.
     */
    public registration() {
    }

    /**
     * Constructor used to store the user's first and last name.
     *
     * @param firstName user's first name
     * @param lastName user's last name
     */
    public registration(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Checks whether the username is correctly formatted.
     *
     * Username must:
     * - Contain an underscore
     * - Be no more than 5 characters long
     *
     * @param username username to validate
     * @return true if username is valid, otherwise false
     */
    public boolean checkuserName(String username) {
        if (username == null) {
            return false;
        }

        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks whether the password meets the complexity requirements.
     *
     * Password must contain:
     * - At least 8 characters
     * - At least one capital letter
     * - At least one number
     * - At least one special character
     *
     * @param password password to validate
     * @return true if password is valid, otherwise false
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecial = true;
            }
        }

        return hasCapital && hasNumber && hasSpecial;
    }

    /**
     * Checks whether the cell phone number is in international format.
     *
     * The number must start with +27 and contain between 9 and 10
     * digits after the country code.
     *
     * @param cellPhone cell phone number
     * @return true if valid, otherwise false
     */
    public boolean checkCellPhoneNumber(String cellPhone) {
        if (cellPhone == null) {
            return false;
        }

        if (!cellPhone.startsWith("+27")) {
            return false;
        }

        String digits = cellPhone.substring(3);

        if (digits.length() < 9 || digits.length() > 10) {
            return false;
        }

        for (int i = 0; i < digits.length(); i++) {
            if (!Character.isDigit(digits.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    /**
     * Registers the user after validating all required information.
     *
     * @param username username
     * @param password password
     * @param cell cell phone number
     * @return registration status message
     */
    public String registerUser(String username, String password, String cell) {

        if (!checkuserName(username)) {
            return "username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cell)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }

        registeredUsername = username;
        registeredPassword = password;
        registeredCellphone = cell;

        return "User successfully registered.";
    }

    /**
     * Checks whether the supplied login details match the registered details.
     *
     * @param username username entered during login
     * @param password password entered during login
     * @return true if login is successful, otherwise false
     */
    public boolean loginUser(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        return registeredUsername != null
                && registeredUsername.equals(username)
                && registeredPassword != null
                && registeredPassword.equals(password);
    }

    /**
     * Returns the appropriate login status message.
     *
     * @param status login status
     * @param firstName user's first name
     * @param lastName user's last name
     * @return login status message
     */
    public String returnLoginStatus(boolean status, String firstName, String lastName) {

        if (status) {
            return "Welcome " + firstName + ", " + lastName
                    + " it is great to see you again.";
        } else {
            return "username or password incorrect, please try again.";
        }
    }

    // Getters

    public String getregisteredUsername() {
        return registeredUsername;
    }

    public String getregisteredPassword() {
        return registeredPassword;
    }

    public String getregisteredCellphone() {
        return registeredCellphone;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}
