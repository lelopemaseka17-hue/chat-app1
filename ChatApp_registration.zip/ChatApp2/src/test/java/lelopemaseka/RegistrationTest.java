package lelopemaseka;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for the registration class, using the exact test data
 * supplied in the POE Part 1 brief.
 */
class RegistrationTest {

    private registration reg;

    @BeforeEach
    void setUp() {
        reg = new registration();
    }

    // ---------- Username tests ----------

    @Test
    void checkUserName_ValidUsername_ReturnsTrue() {
        // Username Pass: kyl_1 -> True
        assertTrue(reg.checkuserName("kyl_1"));
    }

    @Test
    void checkUserName_InvalidUsername_ReturnsFalse() {
        // Username Fail: kyle!!!!!!! -> False
        assertFalse(reg.checkuserName("kyle!!!!!!!"));
    }

    // ---------- Password tests ----------

    @Test
    void checkPasswordComplexity_ValidPassword_ReturnsTrue() {
        // Password Pass: Ch&&sec@ke99! -> True
        assertTrue(reg.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    void checkPasswordComplexity_InvalidPassword_ReturnsFalse() {
        // Password Fail: password -> False
        assertFalse(reg.checkPasswordComplexity("password"));
    }

    // ---------- Cell phone number tests ----------

    @Test
    void checkCellPhoneNumber_ValidNumber_ReturnsTrue() {
        // Cell Pass: +27838968976 -> True
        assertTrue(reg.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    void checkCellPhoneNumber_InvalidNumber_ReturnsFalse() {
        // Cell Fail: 08966553 -> False
        assertFalse(reg.checkCellPhoneNumber("08966553"));
    }

    // ---------- registerUser tests ----------

    @Test
    void registerUser_AllValid_ReturnsSuccessMessage() {
        String result = reg.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("User successfully registered.", result);
    }

    @Test
    void registerUser_InvalidUsername_ReturnsUsernameMessage() {
        String result = reg.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(result.startsWith("username is not correctly formatted"));
    }

    // ---------- loginUser tests ----------

    @Test
    void loginUser_CorrectCredentials_ReturnsTrue() {
        // Login Success -> True
        reg.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(reg.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    void loginUser_IncorrectCredentials_ReturnsFalse() {
        // Login Failed -> False
        reg.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(reg.loginUser("kyl_1", "WrongPass1!"));
    }

    // ---------- returnLoginStatus tests ----------

    @Test
    void returnLoginStatus_Success_ReturnsWelcomeMessage() {
        String message = reg.returnLoginStatus(true, "Kyle", "Smith");
        assertEquals("Welcome Kyle, Smith it is great to see you again.", message);
    }

    @Test
    void returnLoginStatus_Failure_ReturnsErrorMessage() {
        String message = reg.returnLoginStatus(false, "Kyle", "Smith");
        assertEquals("username or password incorrect, please try again.", message);
    }
}
