package lelopemaseka;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for the Message class and its sent/received/read flags.
 */
class MessageTest {

    @Test
    void newMessage_DefaultsToUnsent() {
        Message message = new Message("Hello there");
        assertFalse(message.isSent());
        assertFalse(message.isReceived());
        assertFalse(message.isRead());
        assertEquals("Hello there", message.getPayload());
    }

    @Test
    void markSent_SetsSentFlagOnly() {
        Message message = new Message("Hi");
        message.markSent();
        assertTrue(message.isSent());
        assertFalse(message.isReceived());
        assertFalse(message.isRead());
    }

    @Test
    void markReceived_SetsReceivedFlag() {
        Message message = new Message("Hi");
        message.markReceived();
        assertTrue(message.isReceived());
        assertFalse(message.isRead());
    }

    @Test
    void markRead_SetsAllFlagsTrue() {
        Message message = new Message("Hi");
        message.markRead();
        assertTrue(message.isSent());
        assertTrue(message.isReceived());
        assertTrue(message.isRead());
    }
}
